# AI Match Analyzer — full website starter

This package upgrades the earlier visual prototype into a real website architecture:

- Express backend
- API-Football/API-Sports integration
- live fixture retrieval by date
- league filtering
- match analysis endpoint
- API prediction data
- transparent Poisson goal model
- 1X2, Over 1.5, Over 2.5 and BTTS probabilities
- top correct scores
- responsive neon-green dashboard

## 1. Requirements
- Node.js 18+
- An API-Football/API-Sports key

API-Football currently provides live scores, historical match data, standings, player statistics, bookmaker odds and predictions. Its prediction endpoint can return a predicted winner, estimated score and home/draw/away probabilities.

## 2. Install
1. Extract this ZIP.
2. Open a terminal in the project folder.
3. Run:
   npm install
4. Copy `.env.example` to `.env`.
5. Put your API key in `API_FOOTBALL_KEY`.
6. Run:
   npm start
7. Open:
   http://localhost:3000

## 3. Important production upgrades
For a serious commercial prediction service, add:
- persistent database (PostgreSQL)
- Redis caching/rate limiting
- user accounts
- admin dashboard
- subscription/payment system
- historical prediction storage
- accuracy/Brier-score tracking
- live event polling/webhooks where available
- injuries, lineups, xG and odds from licensed data
- separate model-training service
- audit logs
- HTTPS and secrets management

Do not expose your API key in browser JavaScript. This project keeps the key on the Express server.

## Data provider
API-Football/API-Sports: https://www.api-football.com/
Documentation: https://www.api-football.com/documentation-v3

The app also keeps its own Poisson layer so the site's recommendation is not a black box. It is still a probability model, not a guarantee.
