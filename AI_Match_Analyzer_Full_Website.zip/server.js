require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_FOOTBALL_KEY;
const API_BASE = "https://v3.football.api-sports.io";

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

async function football(endpoint) {
  if (!API_KEY) throw new Error("API_FOOTBALL_KEY is not configured.");
  const r = await fetch(API_BASE + endpoint, {
    headers: { "x-apisports-key": API_KEY }
  });
  if (!r.ok) throw new Error(`Football API HTTP ${r.status}`);
  return r.json();
}

function poisson(lambda, k) {
  return Math.exp(-lambda) * Math.pow(lambda, k) / factorial(k);
}
function factorial(n) { let x=1; for(let i=2;i<=n;i++) x*=i; return x; }

function poissonModel(homeXg=1.45, awayXg=1.10) {
  const rows=[];
  for(let h=0;h<=6;h++) for(let a=0;a<=6;a++)
    rows.push({home:h,away:a,p:poisson(homeXg,h)*poisson(awayXg,a)});
  const total=rows.reduce((s,x)=>s+x.p,0);
  const home=rows.filter(x=>x.home>x.away).reduce((s,x)=>s+x.p,0)/total;
  const draw=rows.filter(x=>x.home===x.away).reduce((s,x)=>s+x.p,0)/total;
  const away=rows.filter(x=>x.home<x.away).reduce((s,x)=>s+x.p,0)/total;
  const lambda=homeXg+awayXg;
  const over15=1-Math.exp(-lambda)*(1+lambda);
  const over25=1-Math.exp(-lambda)*(1+lambda+lambda*lambda/2);
  const btts=1-Math.exp(-homeXg)-Math.exp(-awayXg)+Math.exp(-lambda);
  rows.sort((x,y)=>y.p-x.p);
  return {
    probabilities:{home:+home.toFixed(4),draw:+draw.toFixed(4),away:+away.toFixed(4)},
    markets:{over15:+over15.toFixed(4),over25:+over25.toFixed(4),btts:+btts.toFixed(4)},
    totalXg:+lambda.toFixed(2),
    correctScores:rows.slice(0,5).map(x=>({...x,p:+(x.p/total).toFixed(4)}))
  };
}

// Today's fixtures. league can be an API-Football league id; date is YYYY-MM-DD.
app.get("/api/fixtures", async (req,res)=>{
  try {
    const date = req.query.date || new Date().toISOString().slice(0,10);
    const league = req.query.league;
    const params = new URLSearchParams({date, timezone:"Africa/Douala"});
    if (league) params.set("league", league);
    // If a league is supplied, API-Football requires season in many cases.
    if (league && req.query.season) params.set("season", req.query.season);
    const data = await football(`/fixtures?${params.toString()}`);
    const fixtures=(data.response||[]).map(x=>({
      id:x.fixture.id,
      date:x.fixture.date,
      status:x.fixture.status,
      league:{id:x.league.id,name:x.league.name,country:x.league.country},
      home:{id:x.teams.home.id,name:x.teams.home.name,logo:x.teams.home.logo},
      away:{id:x.teams.away.id,name:x.teams.away.name,logo:x.teams.away.logo},
      goals:x.goals
    }));
    res.json({date,fixtures});
  } catch(e) { res.status(500).json({error:e.message}); }
});

// Full API-Football prediction plus our transparent Poisson layer.
app.get("/api/analyze/:fixtureId", async (req,res)=>{
  try {
    const id=req.params.fixtureId;
    const pred=await football(`/predictions?fixture=${encodeURIComponent(id)}`);
    const p=pred.response?.[0];
    if(!p) return res.status(404).json({error:"No prediction data returned for this fixture."});

    const modelHome=parseFloat(p.predictions?.goals?.home)||1.45;
    const modelAway=parseFloat(p.predictions?.goals?.away)||1.10;
    const poisson=poissonModel(modelHome,modelAway);

    res.json({
      fixtureId:id,
      teams:p.teams,
      league:p.league,
      apiPrediction:p.predictions,
      poisson
    });
  } catch(e) { res.status(500).json({error:e.message}); }
});

app.get("/api/health",(req,res)=>res.json({
  ok:true,
  configured:Boolean(API_KEY),
  message:API_KEY ? "API key configured." : "Add API_FOOTBALL_KEY to .env"
}));

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`AI Match Analyzer running on http://localhost:${PORT}`));
