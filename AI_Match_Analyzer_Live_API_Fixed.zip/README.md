# AI Match Analyzer — Live API fixed version

This version fixes the live football API integration and adds clearer API errors.

## What was fixed
- Checks API-Football's JSON `errors` even when HTTP status is 200.
- Adds the required `season` automatically when a league filter is used.
- Calculates the football season from the selected date (Aug-Dec = current year; Jan-Jul = previous year).
- Adds a real API health check using the API status endpoint.
- Keeps the API key server-side; it is never sent to browser JavaScript.
- Gives useful error messages for missing/invalid API keys and API failures.

## Required setup
You need an API-Football/API-Sports key. The website cannot obtain a private API key automatically.

1. Create an account at https://dashboard.api-football.com/
2. Copy your API key.
3. On Render (or another host), open the service's Environment Variables.
4. Add:
   `API_FOOTBALL_KEY` = your key
5. Redeploy.

Do NOT commit the real key to GitHub.

## Local run
Node.js 18+:

    npm install
    npm start

Then open http://localhost:3000

## Endpoints
- `/api/health` — checks API configuration and API connectivity.
- `/api/fixtures?date=YYYY-MM-DD` — live/date fixtures.
- `/api/fixtures?date=YYYY-MM-DD&league=39` — league fixtures with automatic season.
- `/api/analyze/12345` — API prediction + transparent Poisson layer.

## Production note
The API plan's quota/rate limits still apply. For a commercial site, add caching, a database, scheduled ingestion, authentication and monitoring.
